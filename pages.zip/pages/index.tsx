// pages/index.js
import FoodForm from "@/components/foodForm";
import MealList from "@/components/MealsList";

const Home = () => {
  return (

        <main>
          {/*<MealList />*/}
            <FoodForm/>
        </main>
  );
};

export default Home;
